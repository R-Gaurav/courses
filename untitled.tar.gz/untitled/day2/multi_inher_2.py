class BaseChecker:
    def check(self, value):
        raise Exception("{} not allowed type".format(value))


class Int(BaseChecker):
    def check(self, value):
        if type(value) is not int:
            super().check(value)
        else:
            print("It is an int")


class String(BaseChecker):
    def check(self, value):
        if type(value) is not str:
            super().check(value)
        else:
            print("It is a string")

class IntOrString(Int, String):
    def check(self, value):
        super().check(value)


checker = IntOrString()
checker.check(3)