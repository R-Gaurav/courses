def my_range(n):
    out = []
    counter = 0
    while counter < n:
        out.append(counter)
        counter += 1
    return out

r = my_range(5)

iterator1 = iter(r) # = r.__iter__() i.e. lists have __iter__ method.
iterator2 = iter(r)
iterator3 = iter(r)
iterator4 = iter(r)

print(id(r))
print(id(r))
print(id(iterator1))
print(id(iterator2))
print(id(iterator3))
print(id(iterator4))

while True:
    try:
        i = next(iterator)
        print(i)
    except StopIteration as e:
        break

# print(next(i))
# print(next(i))
# print(next(i))
# print(next(i))
# print(next(i))
# print(next(i))
# for i in r:
#     print(i)