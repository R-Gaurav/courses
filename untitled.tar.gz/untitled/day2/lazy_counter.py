def my_range(n):
    counter = 0
    while counter < n:
        yield counter # Jump is from yield to yield in generators.
        counter += 1

r = my_range(5)
print(r)

iterator1 = iter(r) # = r.__iter__() i.e. lists have __iter__ method.
iterator2 = iter(r)
iterator3 = iter(r)
iterator4 = iter(r)

print(id(r))
print(id(r))
print(id(iterator1))
print(id(iterator2))
print(id(iterator3))
print(id(iterator4))


# for i in r:
#     print(i)