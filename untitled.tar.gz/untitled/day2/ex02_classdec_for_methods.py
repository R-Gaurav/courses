import types
import functools
from enum import Enum

class PrintLevel:
    LOW = 1
    MEDIUM = 2
    HIGH = 3

LEVEL = PrintLevel.HIGH

def __simple_track(cls, print_level):
    def dec(func):
        @functools.wraps(func)
        def inner(*vargs, **kwargs):
            fname = func.__name__
            cls_name = cls.__name__
            if print_level >= LEVEL:
                print("{}.{}:: Called.".format(cls_name, fname))
            ret = None
            try:
                ret = func(*vargs, **kwargs)
            except Exception as e:
                print("{}.{}:: Exception: {}".format(cls_name, fname, e))
                raise
            else:
                if print_level >= LEVEL:
                    print("{}.{}:: Done".format(cls_name, fname))
                return ret
        return inner
    return dec

def track_class(print_level):
    def deco(cls):
        wrapper_func = __simple_track(cls, print_level)
        @functools.wraps(cls)
        def class_wrapper(*args, **kwargs):
            for attr_name, attr in vars(cls).items():
                if type(attr) is types.FunctionType:
                    setattr(cls, attr_name, wrapper_func(attr))
            return cls(*args, **kwargs)
        return class_wrapper
    return deco

@track_class(PrintLevel.HIGH)
class Sample:

    def __init__(self, x):
        print("__init__ called", x)

    def method1(self, a):
        print("method 1 called", a)

    def method2(self, b):
        print("method 2 called", b)

s = Sample(7)
s.method1(2)
s.method2(3)