def __str__(self):
    s = ""
    for k in vars(self):
        s += "{}: {}\n".format(k, vars(self)[k])
    return s

class MyMeta(type):

    @classmethod
    def __prepare__(mcs, name, bases):
        return dict()

    def __new__(mcls, name, bases, namespace):
        print("Meta class new called")
        namespace["CLASS_VAR"] = 140
        namespace["__str__"] = __str__
        return super(MyMeta, mcls).__new__(mcls, name, bases, namespace)

    def __init__(cls, name, bases, namespace):
        print("Meta class init called")
        # print(cls)
        # print(name)
        # print(bases)
        # print(namespace)
        super(MyMeta, cls).__init__(name, bases, namespace)

    def __call__(cls, *args, **kwargs):
        # print(cls)
        # print(args)
        # print(kwargs)
        return super(MyMeta, cls).__call__(*args, **kwargs)
        # obj = cls.__new__(cls, *args, **kwargs)
        # obj.__init__(*args, **kwargs)
        # return obj


class Sample(metaclass=MyMeta):
    CLASS_VAR = 1

    def __new__(cls, *args, **kwargs): # It is class bound method.
        print("new() called!", cls, args, kwargs)
        return super().__new__(cls)

    def __init__(self, a): # It is an object bound method.
        self._a = a

    def get_a(self): # It is an object bound method.
        print("get_a() called!")

# Metaclasses inherit from "type", and Normal Classes inherit from "object".
# __call__ method makes the object of a class callable. Ex: s = Sample(), s(12). It is defined in metaclass.

CLASS_VAR = 1

# def __init__(self, a): # It is an object bound method.
#     print("init called", a)
#     self._a = a
#
# def get_a(self): # It is an object bound method.
#     print("get_a() called!")
#
# Sample = type(
#     "Sample",
#     tuple(),
#     {
#         "CLASS_VAR": CLASS_VAR,
#         "__init__": __init__,
#         "get_a": get_a
#     }
# )
#
s = Sample(12)
s.get_a()
print(s.CLASS_VAR)
print(s.__str__())


