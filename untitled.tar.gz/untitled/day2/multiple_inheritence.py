class A:
    def __init__(self):
        print("A init is called!")

class B(A):
    def __init__(self, b, **kwargs):
        print("B init is called!", b)
        super().__init__(**kwargs) #A.__init__(self)


class C(A):
    def __init__(self, c, **kwargs):
        print("C init is called!", c)
        super().__init__(**kwargs) #A.__init__(self)


class D(B, C):
    def __init__(self, d, **kwargs):
        #B.__init__(self, b)
        #C.__init__(self, c)
        print("D init is called!", d)
        super().__init__(**kwargs)

d = D(1, b=2, c=3)
print(D.mro())

c = C(2)
print(C.mro())
