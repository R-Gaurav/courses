import json

class NamedObjMixin:

    def get_name(self):
        return self.name

    def set_name(self, name):
        self.name = name


class JsonRepMixin:

    def as_json(self):
        return json.dumps(vars(self))


class Sample1(NamedObjMixin, JsonRepMixin):
    def __init__(self, a):
        self.a = 2


class Sample2(NamedObjMixin, JsonRepMixin):
    def __init__(self, c):
        self.c = "test"

s1 = Sample1(2)
s1.set_name("nx1")
print(s1.as_json())

s2 = Sample2(25)
s2.set_name("nx2")
print(s2.as_json())