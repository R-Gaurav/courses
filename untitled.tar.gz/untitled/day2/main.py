import functools
def sub(a, b):
    print(a-b)

# def operate(operator, a, b):
#     func = operator == "+" and add or sub
#     return func(a, b)
#
# print(operate("+", 4, 1))
# print(operate("-", 4, 1))
#


# def operate(operation,a, b):
#     return operation(a, b)
#
# print(operate(add, 4, 1))
# print(operate(sub, 4, 1))


# def operate(operator):
#     return operator == "+" and add or sub
#
# print(operate("+")(4, 3))
# print(operate("-")(4, 3))


# def operate(operator):
#     def operation(a, b):
#         f = operator == "+" and add or sub
#         print(f(a, b))
#     return operation
#
# f1 = operate("+")
# k = f1(4, 3)
# print(k)


import time
from enum import Enum

class InfoLevel(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3

LEVEL = InfoLevel.HIGH

# def timeit(func):
#     fname = func.__name__
#
#     def inner(*vargs, **kwargs):
#         t1 = time.time()
#         k = func(*vargs, **kwargs)
#         print(fname, "took", time.time() - t1)
#         return k
#
#     return inner

def timeit(info_level):
    def dec(func):
        fname = func.__name__
        @functools.wraps(func) # Very important to not lost the context of the decorated function.
        def inner(*vargs, **kwargs):
            t1 = time.time()
            k = func(*vargs, **kwargs)
            if info_level.value >= LEVEL.value:
                print(fname, "took", time.time() - t1)
            return k
        return inner
    return dec


@timeit(InfoLevel.HIGH) # InfoLevel.HIGH is the decorator arg here.
def add(a, b):
    """
    This is a doc string.
    """
    print(a+b)


print(add.__name__)
print(add.__doc__)
print(add(5, 4))