import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
import time

from Queue import Queue

total_time = 0

class Task:
  TID = 0

  def __init__(self, cr):
    self._cr = cr
    Task.TID += 1
    self.tid = Task.TID

  def prime(self):
    return self._cr.next()

  def run(self, val):
    self._cr.send((val, self.tid))

def cube():
    begin = time.time()
    #print "This happens before yielding"
    v, tid = yield LongAction()
    print "tid:", tid, "output", v ** 3
    global total_time
    total_time += time.time() - begin
    yield

import random

class LongAction:
    def __init__(self):
        self.task = None
        self._counter = 0

    def set_callback(self, task):
        self.task = task

    def notify(self):
        self.task.run(random.randint(1, 10))

    def is_done(self):
        self._counter += 1

        # print "check",
        if self._counter <= 100:
            i = random.randint(1, 5)
            return i == 4
        else:
            return True

class Hub:

    def __init__(self):
        self._actions = Queue()

    def add(self, cr):
        task = Task(cr)
        action = task.prime()
        action.set_callback(task)
        self._actions.put(action)

    def start(self):
        while not self._actions.empty():
            action = self._actions.get()
            #print "Action for task", action.task.tid
            if action.is_done():
                # print "done"
                action.notify()
                self._actions.task_done()
            else:
                # print "not done yet"
                self._actions.put(action)
        print self._actions.empty()

pgm_begin = time.time()
tm = Hub()
for i in range(100000):
    tm.add(cube())

tm.start()
pgm_time = time.time() - pgm_begin

print "Prgm time", pgm_time
print "concurrent time", total_time