
from collections.abc import MutableMapping

class MyDict(dict):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def __setitem__(self, key, value):
        print("Setting value for class dictionary", key, value)
        if key in self:
            super().__setitem__(key, [super().__getitem__(key)])
            super().__getitem__(key).append(value)
        else:
            super().__setitem__(key, value)
        print(self)

class MultiValue(type):

    @classmethod
    def __prepare__(mmcls, name, bases):
        return MyDict()

    def __new__(mcls, name, bases, namespace):
        print("ns", namespace)
        return super(MultiValue, mcls).__new__(mcls, name, bases, namespace)

class Sample(metaclass=MultiValue):

    def __init__(self):
        pass

    def m1(self):
        pass

    def m2(self):
        print("Without arg")

    def m2(self, x):
        print("With arg", x)

# print(vars(Sample1))
print(Sample.m1)
s = Sample()
Sample.m2[0](s)
Sample.m2[1](s, 25)
