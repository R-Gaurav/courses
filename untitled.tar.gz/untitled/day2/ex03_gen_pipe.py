
def provide_line(file_path):
    f = open(os.path.join(my_dir, "./ex00_input.csv"), "r")
    while True:
        line = f.readline()
        if line == "": 
            raise StopIteration()
        else:
            yield line.strip()

def convert_line_to_ints(file_path):
    line_provider = provide_line(file_path)
    for line in line_provider:
        yield (int(i.strip()) for i in line.split(","))

def add_line_contents(file_path):
    ints_provider = convert_line_to_ints(file_path)
    for int_gen in ints_provider:
        yield sum(int_gen)

import sys, os
my_dir = os.path.dirname(os.path.realpath(__file__))
adder = add_line_contents(os.path.join(my_dir, "./ex00_input.csv"))

for output in adder:
    print(output)

