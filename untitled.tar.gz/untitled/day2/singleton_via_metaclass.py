class Singleton(type):

    def __call__(cls, *args, **kwargs):
        if not hasattr(cls, "_INSTANCE") or cls._INSTANCE is None:
            obj = cls.__new__(cls, *args, *kwargs)
            obj.__init__(*args, **kwargs)
            cls._INSTANCE = obj
        return cls._INSTANCE


class Sample(metaclass=Singleton):
    pass

s1 = Sample()
s2 = Sample()

assert s1 is s2