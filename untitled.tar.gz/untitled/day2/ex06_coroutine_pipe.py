# David Beazley on Coroutines video

def provide_line(file_path):
    f = open(os.path.join(my_dir, "./ex00_input.csv"), "r")
    while True:
        line = f.readline()
        if line == "": 
            f.close()
            raise StopIteration()
        else:
            yield line.strip()

def convert_line_to_ints(file_path):
    line_provider = provide_line(file_path)
    for line in line_provider:
        yield (int(i.strip()) for i in line.split(","))

def add_line_contents(file_path):
    ints_provider = convert_line_to_ints(file_path)
    for int_gen in ints_provider:
        # We are making a slight change here to get original added numbers
        numbers = tuple(int_gen)
        yield numbers, sum(numbers)

def write_string_line_to_file(file_path):
    f = open(file_path,"w")
    while True:
        strings = yield
        if strings is None:
            f.close()
            break
        f.write(",".join(strings) + os.linesep)

def write_sum_to_file(file_path):
    line_writer = write_string_line_to_file(file_path)
    # line_writer.send(None)
    next(line_writer)
    while True:
        ints = yield
        if ints is None:
            line_writer.send(None)
            break
        else:
            line_writer.send([str(i) for i in ints])      

import sys, os
my_dir = os.path.dirname(os.path.realpath(__file__))
adder = add_line_contents(os.path.join(my_dir, "./ex00_input.csv"))
writer = write_sum_to_file(os.path.join(my_dir, "./output.csv"))
writer.send(None)
for output in adder:
    print(output)
    writer.send((*output[0], output[1]))
try:
    writer.send(None)
except StopIteration as e:
    # expected
    pass

