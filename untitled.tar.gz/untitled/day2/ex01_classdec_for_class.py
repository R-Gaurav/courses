import functools

def singleton(cls):
    @functools.wraps(cls)
    def inner(*args, **kwargs):
        if not hasattr(cls, '_INSTANCE') or cls._INSTANCE is None:
            cls._INSTANCE = cls(*args, **kwargs)
        return cls._INSTANCE
    return inner

@singleton
class Sample1:
    pass

@singleton
class Sample2:
    pass

s1 = Sample1()
s2 = Sample1()

s3 = Sample2()
s4 = Sample2()

print(s1 is s2)
print(s3 is s4)
print(s1 is s3)
print(s1 is s4)
print(s2 is s3)
print(s2 is s4)
