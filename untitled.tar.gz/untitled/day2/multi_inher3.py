class A:
    pass

class B(A):
    pass

class C(A):
    pass

class D(B, C):
    pass

class E(B, C): # (C, B) causes mro related problem
    pass

class F(D, E):
    pass
