import pythonic
import unpythonic
import time
import timeit

#
# t1 = time.time()
# pythonic.csum()
# print(time.time()-t1)
#
# t2 = time.time()
# unpythonic.csum()
# print(time.time()-t2)

u_reading = timeit.repeat("unpythonic.csum()", number=15, repeat=5, setup="import unpythonic")
print(u_reading)

import numpy
arr = numpy.array(u_reading) / 15
print(numpy.mean(arr))
