from setuptools import setup, find_packages

setup(
    name="mymath",
    version="0.1",
    author="Gaurav",
    packages=find_packages(),
    install_requires=["requests"]
)
