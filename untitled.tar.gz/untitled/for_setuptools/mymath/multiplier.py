import functools
 
def __multiply_2_values(a,b):
    return a * b
 
def multiply(*args):
    if len(args) == 0: return 1
    return functools.reduce(__multiply_2_values, args)