from mymath.multiplier import multiply

print(multiply(1,2,3,4))