import sys
import time

l = []
point_of_realloc = False

def print_info(in_list, t):
    global point_of_realloc
    items = len(in_list)
    allocated = (sys.getsizeof(in_list) - 64)//8
    empty = allocated - items
    if empty == 0:
        print("---- reallocation line --------")
        point_of_realloc = True
        return
    if point_of_realloc:
        print("Items {}: Allocated: {}: Extra: {}".format(items, allocated, empty))
        point_of_realloc = False
        print("Time: ", t * 1000, "ms")

print_info(l, 0)
for i in range(100000):
    t0 = time.time()
    l.append(1)
    t1 = time.time()
    print_info(l, t1-t0)


'''
Items 91594: Allocated: 91594: Extra: 0
---- reallocation line --------
Items 91595: Allocated: 103050: Extra: 11455
'''
