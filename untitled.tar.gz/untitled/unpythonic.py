@profile
def csum(n=1000000):
    total = 0
    for i in range(n):
        total += i
    return total