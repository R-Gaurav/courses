@profile
def csum(n=1000000):
    total = sum(range(n))
    return total