
import threading
import time

def fib(n=50000):
    a,b = 0,1
    for i in range(n):
        a,b = b, a+b

iterations = 10

print("Non-threaded")
t1 = time.time()
for i in range(iterations):
    fib()
print(time.time()-t1)

print("Threaded")
threads = list()

t2 = time.time()
for i in range(iterations):
    x = threading.Thread(target=fib, args=(50000,))
    threads.append(x)
    x.start()

for thread in threads:
    thread.join()
print(time.time()-t2)

