
import threading
import time
from urllib.request import urlopen

import ssl
context = ssl._create_unverified_context()

def read():
    # time.sleep(5)
    urlopen("http://www.nutanix.com/", context=context)

iterations = 5

print("Non-threaded")
t1 = time.time()
for i  in range(iterations):
    read()
print(time.time()-t1)

print("Threaded")
threads = list()

t2 = time.time()
for i in range(iterations):
    x = threading.Thread(target=read)
    threads.append(x)
    x.start()

for thread in threads:
    thread.join()
print(time.time()-t2)

