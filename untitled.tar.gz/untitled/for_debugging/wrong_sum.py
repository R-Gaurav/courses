import rpdb

debugger = rpdb.Rpdb(port=12345)

def doublelevel(argsum, val):
    argsum = 0
    new_val = argsum + val
    return new_val
 
values = range(1, 11)
 
mysum = 0

debugger.set_trace()
for val in values:
    mysum = doublelevel(mysum, val)
 
print(mysum)