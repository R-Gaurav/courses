import pythonic, unpythonic

pythonic.csum()
unpythonic.csum()

#  python -m cProfile -s tottime main_file1.py
#  python -m cProfile -s ncalls main_file1.py


# (tm35) trainee@ip-172-31-8-52:~/_workdir/pycharm-workspace/untitled$ python -m cProfile -o profstats  main_file1.py
# (tm35) trainee@ip-172-31-8-52:~/_workdir/pycharm-workspace/untitled$ python -m pstats profstats
# Welcome to the profile statistics browser.
# profstats% sort ncalls
# profstats% stats

# pstats library/module in python

#  pip install line_profiler
#  kernprof -l -v -o input.test main_file1.py  (to know which pyhthon sttement should be changed. )

# 1 MebiByte = 2^20 byrtes
# 1 MiB = 1.05 MB


#  python -m mprof run main_file1.py
#  python -m mprof plot mprofile_20190515091833.dat

# pip install snakeviz
# pip install pyprof2calltree

#  from pympler.asizeof import asizeof # to measure sizes accurately
# asizeof([1])
